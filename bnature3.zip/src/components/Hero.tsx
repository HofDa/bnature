import Icon from './ui/Icon';
import { Leaf, BadgeCheck } from 'lucide-react';

export default function Hero() {
  return (
    <section className="section-muted">
      <div className="container grid lg:grid-cols-2 gap-10 items-center">
        <div>
          <span className="badge">
            <Icon as={Leaf} />
            bnature · Monitoring, Bildung, Beratung
            <span className="ml-2 inline-flex items-center gap-1 text-leaf-700">
              <Icon as={BadgeCheck} size={18} />
              geprüft
            </span>
          </span>
          <h1 className="mt-6 h1">
            Biodiversität messbar machen.
            <br /> Lebensräume naturnah gestalten.
          </h1>
          <p className="mt-5 lead max-w-prose">
            Wissenschaft, Praxis und Storytelling – für messbare ökologische
            Wirkung.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#kontakt" className="btn-primary">
              Projekt anfragen
            </a>
            <a href="#leistungen" className="btn-ghost">
              Leistungen ansehen
            </a>
          </div>
          <p className="mt-4 text-sm text-gray-500">
            Bereits im Einsatz bei Gemeinden, Naturparks & Bildungsbetrieben
          </p>
        </div>

        <div className="relative">
          {/* Ersetze /hero-light.jpg durch dein Bild */}
          <img
            src="/hero-light.jpg"
            alt="bnature – Naturmonitoring & Umweltbildung"
            className="rounded-2xl shadow-md ring-1 ring-gray-200 w-full"
          />
          <div className="absolute -bottom-6 left-6 hidden md:block">
            <div className="rounded-2xl bg-white/90 backdrop-blur ring-1 ring-gray-200 p-4 shadow-sm">
              <p className="text-sm text-gray-600">
                &gt;120 ha beraten · 30+ Monitoring-Flächen
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
